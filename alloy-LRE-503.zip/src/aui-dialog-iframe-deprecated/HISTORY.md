# AUI Dialog Iframe Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master-deprecated/src/aui-dialog-iframe-deprecated).

## @VERSION@

* [AUI-3127](https://issues.liferay.com/browse/AUI-3127) IFrame dialog cannot be closed with the escape key if an action on the dialog causes it to reload
* [AUI-3122](https://issues.liferay.com/browse/AUI-3122) iframe is created without title attribute
