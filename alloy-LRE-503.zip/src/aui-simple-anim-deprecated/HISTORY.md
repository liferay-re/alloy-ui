# AUI Simple Anim Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master-deprecated/src/aui-simple-anim-deprecated).

## @VERSION@

No registries yet.
