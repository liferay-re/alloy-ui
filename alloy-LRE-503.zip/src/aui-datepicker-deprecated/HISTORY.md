# AUI DatePicker Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master-deprecated/src/aui-datepicker-deprecated).

## @VERSION@

* [AUI-3164](https://issues.liferay.com/browse/AUI-3164) DatePicker doesn't show a message informing that the date pasted in the field is invalid. Instead it sets the current date
* [AUI-3133](https://issues.liferay.com/browse/AUI-3133) Conflict with aui-datepicker and aui-datepicker-deprecated