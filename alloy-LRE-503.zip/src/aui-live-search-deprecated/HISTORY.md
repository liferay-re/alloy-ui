# AUI Live Search Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master-deprecated/src/aui-live-search-deprecated).

## @VERSION@

No registries yet.

## [3.1.0](https://github.com/liferay/alloy-ui/releases/tag/3.1.0)

* [AUI-1817](https://issues.liferay.com/browse/AUI-1817) The search box in pagination displays an extra empty white box
